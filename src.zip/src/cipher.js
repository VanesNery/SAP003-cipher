window.cipher={
   encode:encode,
   decode:decode
};

function encode(offset,string){
  let Mssg=[];
      for(let i=0; i<string.length;i++){
      let message=string.charCodeAt([i]);//Cifra (codigodaletra + deslo)%tamanhodoalfabeto+codigodaletra
      let msg=String.fromCharCode(message); 

            if(msg.toLocaleUpperCase() === msg){
               message=(message + offset)%26 +65;
               }
               else{
                  message=(message + offset)%26 +97; 
                  }
      Mssg.push(msg);
      }
      return Mssg.join("");
}
   
   function decode(offset,string){
      let Mssg=[];
      for(let i=0; i<string.length;i++){
      let message=(string.charCodeAt([i]) - offset)%26 +65;
      let msg=String.fromCharCode(message); 
      Mssg.push(msg);
      }
      return Mssg.join("");
   }
   //Decifra ((codigoasc - deslo) %tamanhoDOalfabeto + codigodaletra)
   // function encode(offset,string){
   //    let Mssg=[];
   //        for(let i=0; i<string.length;i++){
   //        let message=(string.charCodeAt([i]) + offset)%26 +65;//Cifra (codigodaletra + deslo)%tamanhodoalfabeto+codigodaletra
   //        let msg=String.fromCharCode(message); 
   //        Mssg.push(msg);
   //        }
   //        return Mssg.join("");
   //  }